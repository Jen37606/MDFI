//
//  PlaceInfoViewController.m
//  Project3
//
//  Created by Jennifer Johnson on 6/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "PlaceInfoViewController.h"
#import "FirstViewController.h"
#import "MyMapAnnotation.h"
#import <Mapkit/Mapkit.h>

@implementation PlaceInfoViewController

@synthesize mapView, name, which, coordinateLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */



 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad
 
{
     MKCoordinateSpan span;
     span.latitudeDelta = .02f;
     span.longitudeDelta = .02f;
     CLLocationCoordinate2D location;
    
    if (which == 0) {
         //arlington
         location.latitude = 38.855467f;
         location.longitude = -77.050105f;
     }else if(which == 1){
         //dc palisades
         location.latitude = 38.916961f;
         location.longitude = -77.095786f;
     }else if(which == 2){
         //capital heights
         location.latitude = 38.869802f;
         location.longitude = -76.847958f;
     }else if(which == 3){
         //waldorf
         location.latitude = 38.617105f;
         location.longitude = -76.925504f;
     }else if(which == 4){
         //alexandria
         location.latitude = 38.74923f;
         location.longitude = -77.086025f;
     }else if(which == 5){
         //greenbelt
         location.latitude = 38.993088f;
         location.longitude = -76.878723f;
     }else if(which == 6){
         //chinatown
         location.latitude = 38.899074f;
         location.longitude = -77.019121f;
     }else if(which == 7){
         //springfield
         location.latitude = 38.781362f;
         location.longitude = -77.187072f;
     }else if(which == 8){
         //forestville
         location.latitude = 38.848574f;
         location.longitude = -76.882938f;
     }else if(which == 9){
         //woodbridge
         location.latitude = 38.644101f;
         location.longitude = -77.294142f;
     }
     
         
     MKCoordinateRegion region;
     region.center = location;
     region.span = span;
     mapView.region = region;
     
     CLLocationCoordinate2D arlington;
     arlington.latitude = 38.855467f;
     arlington.longitude = -77.050105f;
     
     CLLocationCoordinate2D palisades;
     palisades.latitude = 38.916961f;
     palisades.longitude = -77.095786f;
     
     CLLocationCoordinate2D capitalHeights;
     capitalHeights.latitude = 38.869802f;
     capitalHeights.longitude = -76.847958f;
     
     CLLocationCoordinate2D waldorf;
     waldorf.latitude = 38.617105f;
     waldorf.longitude = -76.925504f;
     
     CLLocationCoordinate2D alexandria;
     alexandria.latitude = 38.74923f;
     alexandria.longitude = -77.086025f;
     
     CLLocationCoordinate2D greenbelt;
     greenbelt.latitude = 38.993088f;
     greenbelt.longitude = -76.878723f;
     
     CLLocationCoordinate2D chinaTown;
     chinaTown.latitude = 38.899074f;
     chinaTown.longitude = -77.019121f;
     
     CLLocationCoordinate2D springfield;
     springfield.latitude = 38.781362f;
     springfield.longitude = -77.187072f;
     
     CLLocationCoordinate2D forestville;
     forestville.latitude = 38.848574f;
     forestville.longitude = -76.882938f;
     
     CLLocationCoordinate2D woodbridge;
     woodbridge.latitude = 38.644101f;
     woodbridge.longitude = -77.294142f;
     
    
     if(which == 0)
     {
         MyMapAnnotation *annotation = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Arlington, VA" coord:arlington];
         if(annotation != nil){
             [mapView addAnnotation:annotation];
         }
     }else if(which == 1){
         MyMapAnnotation *annotation2 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Washington D.C. (Palisades)" coord:palisades];
         if(annotation2 != nil){
             [mapView addAnnotation:annotation2];
         }
     }else if(which == 2){
         MyMapAnnotation *annotation3 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Capital Heights, MD" coord:capitalHeights];
         if(annotation3 != nil){
             [mapView addAnnotation:annotation3];
         }
     }else if(which == 3){
         MyMapAnnotation *annotation4 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Waldorf, MD" coord:waldorf];
         if(annotation4 != nil){
             [mapView addAnnotation:annotation4];
         }
     }else if(which == 4){
         MyMapAnnotation *annotation5 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Alexandria, MD" coord:alexandria];
         if(annotation5 != nil){
             [mapView addAnnotation:annotation5];
         }
     }else if(which == 5){
         MyMapAnnotation *annotation6 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Greenbelt, MD" coord:greenbelt];
         if(annotation6 != nil){
             [mapView addAnnotation:annotation6];
         }
     }else if(which == 6){
         MyMapAnnotation *annotation7 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Washington D.C. (China Town)" coord:chinaTown];
         if(annotation7 != nil){
             [mapView addAnnotation:annotation7];
         }
     }else if(which == 7){
         MyMapAnnotation *annotation8 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Springfield, VA" coord:springfield];
         if(annotation8 != nil){
             [mapView addAnnotation:annotation8];
         }
     }else if(which == 8){
         MyMapAnnotation *annotation9 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Forestville, MD" coord:forestville];
         if(annotation9 != nil){
             [mapView addAnnotation:annotation9];
         }
     }else if(which == 9){
         MyMapAnnotation *annotation10 = [[MyMapAnnotation alloc] initWithTitle:@"The Noodle Place - Woodbridge, VA" coord:woodbridge];
         if(annotation10 != nil){
             [mapView addAnnotation:annotation10];
         }
     }
    
     
 [super viewDidLoad];
 }


- (void)viewWillAppear:(BOOL)animated {
    name.text = nil;
    
    NSLog(@"%@", name);
    NSLog(@"%d", which);
    [super viewWillAppear:animated];
}

- (void)viewDidUnload
{
    self.title = nil;
    //self.message = nil;
    //self.which = nil;
    //self.lon = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
